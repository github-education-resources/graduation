from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate
import dash_core_components as dcc
import dash_html_components as html

from .server import app, redis_conn

from flask_login import current_user
from flask import send_file
import dill
import pickle
import json
from io import BytesIO


def manage_models_layout():

    user_models = redis_conn.keys(f"{current_user.username}_trainedModel_*")
    user_models = [model.decode() for model in user_models]

    return [
        # The tab menu
        html.Div([
            html.H4("Select a model"),
            dcc.Dropdown(options=[{'label': model, 'value': model}
                                  for model in user_models],
                         id="user_models"),

            html.Br(),
            html.Button("Delete selected model",
                        id="remove_selected_model"),

            html.Br(),
            html.Br(),
            html.A(html.Button("Download model (pickle)"),
                   target="_blank", id="download_model_link",
                   className="link_button")

        ], id="user_models_list"),

        # The main content
        html.Div(id="user_model_preview"),
    ]


@app.callback(Output("user_models", "options"),
              [Input("remove_selected_model", "n_clicks")],
              [State("user_models", "value")])
def show_available_models(n_clicks, selected_model):

    # Get list of current models
    user_models = redis_conn.keys(f"{current_user.username}_trainedModel_*")
    user_models = [model.decode() for model in user_models]

    # delete model...
    # redis_conn.delete...

    # return the rest of the choices...
    return [{'label': model, 'value': model}
            for model in user_models]


@app.callback([Output("user_model_preview", "children"),
               Output("download_model_link", "href")],
              [Input("user_models", "value")])
def inspect_model(selected_model):

    if selected_model is None:
        raise PreventUpdate

    model_params_key = selected_model.replace("trainedModel",
                                              "trainedModelParams")
    user_model_params = dill.loads(redis_conn.get(model_params_key))

    return [
        html.Pre(json.dumps(user_model_params, indent=4,
                            sort_keys=False)),

        f"/devops/models/{selected_model}"
    ]


@app.server.route('/models/<string:model_name>')
def send_model_file(model_name):
    if not model_name.startswith(current_user.username):
        raise Exception("UNAUTHORIZED ACCESS!")

    data_string = BytesIO()
    user_model = dill.loads(redis_conn.get(model_name))

    data_string.write(pickle.dumps(user_model))
    data_string.seek(0)

    return send_file(data_string, as_attachment=True,
                     attachment_filename=f"{model_name}.pkl")
