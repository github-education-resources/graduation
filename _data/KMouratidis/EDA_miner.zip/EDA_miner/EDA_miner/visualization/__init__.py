"""
Developer notes:
    Some suggestions on what could be done here:
        - Prettify layout and user interface.
        - Implement the interface to allow the user to create their own KPIs.
        - Work on the DashboardMaker (i.e. dash_rnd) or 3D graphs.
"""

