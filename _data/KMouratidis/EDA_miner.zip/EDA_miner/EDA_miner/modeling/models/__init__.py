"""
Developer notes:
    Some suggestions on what could be done:
        - Improve handling of pipeline traversal and creation.
        - Add new classes for the pipelines (inputs, transformers, \
        data cleaners, models).
        - Improve handling of data / use better data structures.
"""