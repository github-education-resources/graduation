from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html

from .server import app, redis_conn
from utils import parse_contents

from flask_login import current_user


app.layout = html.Div(children=[

    # Choose a task
    dcc.RadioItems(options=[
        {"value": "recommender", "label": "Recommender system"},
        {"value": "duplicates", "label": "Find duplicate items"},
        {"value": "similar", "label": "Find similar items"},
    ], id="task_type"),

    # Select a training dataset


    # Other options

    # Build the REST API
    html.Div(id="content"),
])


@app.callback(Output('output-data-upload', 'children'),
              [Input('upload_data_button', 'contents')],
              [State('upload_data_button', 'filename'),
               State('upload_data_button', 'last_modified')])
def parse_uploads(content, name, date):
    """
    Load and store the uploaded data.

    Args:
        list_of_contents (list(bytes)): The file contents that need to \
                                        be parsed.
        list_of_names (list(str)): The original filenames.
        list_of_dates (list(str)): The modification (?) dates of files.

    Returns:
        list: A list of dash components.
    """

    user_id = current_user.username

    if content is not None:
        response = parse_contents(contents=content, filename=name, date=date,
                                   user_id=user_id, redis_conn=redis_conn)


        return response



@app.callback(Output('content', 'children'),
              [Input('task_type', 'value')])
def tab_subpages(task_type):

    if task_type == 'recommender':
        return "Recommender"

    elif task_type == "duplicates":
        return "LSH"

    else:
        return "KNN"


@app.callback(Output('output', 'children'),
              [Input('upload', 'fileNames')])
def display_files(fileNames):
    if fileNames is not None:
        return html.Ul([html.Li(
            html.Img(height="50", width="100", src=x)) for x in fileNames])
    return html.Ul(html.Li("No Files Uploaded Yet!"))