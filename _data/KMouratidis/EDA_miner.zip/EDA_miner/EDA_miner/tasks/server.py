from dash import Dash
from redis import Redis


app = Dash(__name__,
           external_stylesheets=["https://codepen.io/rmarren1/pen/eMQKBW.css"])

app.config["suppress_callback_exceptions"] = True

redis_conn = Redis()
