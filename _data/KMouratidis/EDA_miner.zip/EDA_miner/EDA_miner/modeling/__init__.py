"""
Developer notes:
    Some suggestions on what could be done:
        - Better reporting on fitting results.
        - Download a model.
        - Predict a test set.
        - Prettier interfaces.
        - Implement Econometrics functionality.
"""


