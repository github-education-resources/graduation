from flask import Flask, request, jsonify, send_file
from flask_caching import Cache
from redis import Redis
import numpy as np
from uuid import uuid4
import dill
import pickle
from io import BytesIO
import sqlite3


app = Flask(__name__)

cache = Cache(app, config={'CACHE_TYPE': 'redis'})
redis_conn = Redis()


@cache.memoize(timeout=15*60)
def get_user(token):
    with sqlite3.connect("users.db") as db_conn:
        cursor = db_conn.cursor()
        user = cursor.execute(
            f'SELECT * FROM user WHERE api_token="{token}"'
        ).fetchone()
        cursor.close()

    return user


@app.route("/api/v1/<string:model_name>/predict", methods=["POST"])
def model_predict(model_name):
    # e.g. "Token adhahg834thqgfasrbg74"
    token = request.headers["Authorization"].split(" ")[1]
    # Get the user using the supplied token
    user = get_user(token)

    # Get models for this user, and check it the model
    # given is one of them
    user_models = [k.decode() for k in
                   redis_conn.keys(f"{user[1]}_trainedModel_*")]

    if f"{user[1]}_trainedModel_{model_name}" not in user_models:
        return jsonify({"message": "Model not in user models."}), 403

    data = np.array(request.json["data"])

    return jsonify({
        "message": "Model prediction successful.",
        "response_data": (data * 2).data.tolist()
    }), 200


@app.route("/api/v1/<string:model_name>/get_model")
def get_model_link(model_name):
    # e.g. "Token adhahg834thqgfasrbg74"
    token = request.headers["Authorization"].split(" ")[1]
    # Get the user using the supplied token
    user = get_user(token)

    # Get models for this user, and check it the model
    # given is one of them
    user_models = [k.decode() for k in
                   redis_conn.keys(f"{user[1]}_trainedModel_*")]

    model_key = f"{user[1]}_trainedModel_{model_name}"

    if model_key not in user_models:
        return jsonify({"message": "Model not in user models."}), 403

    # Create a special download link with expiration
    download_token = str(uuid4())
    redis_conn.set(download_token, model_key, ex=3600)

    return jsonify({
        "message": "Your model is ready. The link will work for 1 hour.",
        "download_url": f"/api/v1/{model_name}/get_model/{download_token}"
    }), 200


@app.route("/api/v1/<string:model_name>/get_model/<string:download_token>")
def get_model(model_name, download_token):

    model_key = redis_conn.get(download_token)
    if model_key is None:
        return jsonify({"message": "No model was sent."}), 404

    user_model = dill.loads(redis_conn.get(model_key))

    data_string = BytesIO()
    data_string.write(pickle.dumps(user_model))
    data_string.seek(0)

    return send_file(data_string, as_attachment=True,
                     attachment_filename=f"{model_name}.pkl"), 200


if __name__ == "__main__":
    app.run(debug=True, port=8001)
