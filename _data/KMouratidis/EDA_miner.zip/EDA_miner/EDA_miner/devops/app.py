from dash.dependencies import Input, Output
import dash_core_components as dcc
import dash_html_components as html

from .server import app
from .manage_models import manage_models_layout
from .test_api import test_api_layout

from flask_login import login_required
from utils import interactive_menu


app.layout = html.Div(children=[

    *interactive_menu(output_elem_id="sidenav2_contents"),

    dcc.Tabs(id="tabs", value='test_api', children=[
        dcc.Tab(label='Manage models', value='manage_models',
                id="manage_models"),
        dcc.Tab(label='Test API', value='test_api',
                id="test_api"),
    ]),

    # Placeholder div for actual contents
    html.Div(id="devops-content"),
])


@app.callback([Output("sidenav2_contents", "children"),
               Output('devops-content', 'children')],
              [Input('tabs', 'value')])
@login_required
def tab_subpages(tab):

    if tab == 'manage_models':
        return manage_models_layout()

    else:
        return test_api_layout()
