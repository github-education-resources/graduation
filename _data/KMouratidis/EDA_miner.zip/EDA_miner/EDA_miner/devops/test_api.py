from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate
import dash_core_components as dcc
import dash_html_components as html

import dash_editor_components

from .server import app, redis_conn

import base64
import io
import os
import pandas as pd
import requests
import json
from flask_login import current_user


def test_api_layout():

    user_models = [k.decode().split("_")[-1] for k in redis_conn.keys(
        f"{current_user.username}_trainedModel_*"
    )]

    return [

        html.Div([
            html.Button("Do something"),
        ]),

        html.Div([

            html.Div([

                html.Div([
                    dcc.Dropdown(id="request_endpoint", options=[
                        {"label": "Get model", "value": "get_model"},
                        {"label": "Predict", "value": "predict"},
                        {"label": "Re-train", "value": "retrain"},
                    ], value="predict"),
                ], className="col-2"),
                html.Div([
                    dcc.Dropdown(id="selected_model", options=[
                        {"label": model, "value": model}
                        for model in user_models
                    ]),
                ], className="col-2"),
                html.Div(dcc.Input(id="request_url",
                                   value="http://edaminer.com/api/v1/"
                                         "{model}/{endpoint}",
                                   placeholder="http://edaminer.com/api/v1/"
                                               "{model}/{endpoint}"),
                         className="col-6"),
                html.Div(html.Button("POST", id="request_type_button"),
                         className="col-1")
            ], className="test_api_header request_line"),

            html.Div([

                html.Div(html.P("API Request"),
                         className="test_api_header"),

                html.Div([
                    # dcc.Tabs(children=[
                    #     dcc.Tab(label="Data upload", value="data", id="data"),
                    #     dcc.Tab(label="JSON", value="json", id="json"),
                    # ], id="api_request_type", value="data"),
                    #
                    # html.Div(id="api_request_input"),

                ], id="test_api_contents"),

                html.Div(id="request_data", style={"display": "none"}),

            ], className="api_request"),

            html.Div([
                html.Div(html.P("API Response"),
                         className="test_api_header"),
                html.Div([
                    dash_editor_components.PythonEditor(disabled=True,
                                                        id='response_editor',
                                                        value="""{
    "hello": 5,
    "array": [1,2,3,4],
}"""),
                ], className="test_api_contents"),
            ], className="api_response"),

        ], id="test_api_content"),
    ]


@app.callback(Output("response_editor", "value"),
              [Input("request_type_button", "n_clicks")],
              [State("request_url", "value"),
               State("request_data", "children")])
def execute_query(n_clicks, request_url, request_data):
    model_name, endpoint = request_url.split("/")[-2:]
    token = current_user.api_token

    if endpoint == "predict":

        response = requests.post(request_url,
                                 headers={"Authorization": f"Token {token}"},
                                 json={"data": json.loads(request_data)["data"]})

        return json.dumps(response.json(), indent=4)

    elif endpoint == "get_model":
        response = requests.get(request_url,
                                headers={"Authorization": f"Token {token}"})

        return json.dumps(response.json(), indent=4)


@app.callback([Output("request_url", "value"),
               Output("request_type_button", "children")],
              [Input("request_endpoint", "value"),
               Input("selected_model", "value")])
def render_request_url(endpoint, model):
    model = model or "{model}"
    endpoint = endpoint or "{endpoint}"
    url = f"http://edaminer.com/api/v1/{model}/{endpoint}"

    if endpoint == "predict":
        method = "POST"

    elif endpoint == "retrain":
        method = "POST"

    elif endpoint == "get_model":
        method = "GET"

    else:
        raise PreventUpdate()

    return url, method


@app.callback(Output("request_data", "children"),
              [Input("request_editor", "value")])
def save_data_to_hidden_div(post_data):
    # TODO: use store & implement uploaded data
    return post_data or {"data": [0, ]}


@app.callback(Output("test_api_contents", "children"),
              [Input("request_url", "value")])
def render_request_menu_parent(request_url):
    if request_url.endswith("get_model"):
        return "No data is supposed to be sent."

    elif request_url.split("/")[-1] in ["predict", "retrain"]:
        return [
            dcc.Tabs(children=[
                dcc.Tab(label="Data upload", value="data", id="data"),
                dcc.Tab(label="JSON", value="json", id="json"),
            ], id="api_request_type", value="json"),

            html.Div(id="api_request_input"),
        ]

    else:
        raise PreventUpdate()


@app.callback(Output("api_request_input", "children"),
              [Input("api_request_type", "value"),
               Input("request_url", "value")])
def render_request_menu(request_type, request_url):
    if request_url.endswith("get_model"):
        return "No data is supposed to be sent."

    if request_type == "data":
        # TODO: Use dcc.Store to implement this
        return [
            html.A(dcc.Upload(
                id='request_editor',
                children=html.Div('Drag and Drop or Select File'),
                multiple=True,
            )),
        ]

    elif request_type == "json":
        return [
            dash_editor_components.PythonEditor(id='request_editor',
                                                value="""{
    "variable": "greeting",
    "data": [2, 4, 6, 8]
}"""),
        ]

    else:
        return []


# Inspired by the Dash docs
@app.callback(Output('output-data-upload', 'children'),
              [Input('test_data_button', 'contents')],
              [State('test_data_button', 'filename'),
               State('test_data_button', 'last_modified')])
def parse_uploads(list_of_contents, list_of_names,
                  list_of_dates):

    if list_of_contents is not None:
        df = [parse_contents(c, n, d) for c, n, d
              in zip(list_of_contents, list_of_names, list_of_dates)][0]

        return df[:5].to_dict()

    else:
        raise PreventUpdate


# Taken straight out the Dash Docs (shorter version here than utils.py).
def parse_contents(contents, filename, date):

    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)

    name, extension = os.path.splitext(filename)

    try:
        if extension == ".csv":
            df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
            df.to_csv(filename)
            return html.Div("Data uploaded successfully.")

        else:
            return html.Div('Format not yet supported.')

    except:
        return html.Div('There was an error processing this file.')

