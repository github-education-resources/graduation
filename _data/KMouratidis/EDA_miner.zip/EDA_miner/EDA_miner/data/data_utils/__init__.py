"""
Developer notes:

The modules here are for implementing utilities needed by higher-level
modules. Some suggestions on what could be done:
    - Add new API connections (note: you need to implement both
    the connector and define a layout/form).
    - Fix the bug that made me pollute the whole file with those
    ugly debugger layouts.
"""